Follow PROJECT\_RULES.md strictly.

