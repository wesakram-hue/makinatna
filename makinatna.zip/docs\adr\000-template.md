# ADR-XXXX: Title
Date:
Status: Proposed | Accepted | Deprecated

## Context
What changed and why?

## Decision
What are we changing?

## Alternatives
What else did we consider?

## Consequences
What breaks? What migrations needed?

## Rollback plan
How to revert safely?
